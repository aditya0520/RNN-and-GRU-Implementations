def question_1():
    # return ""
    return 'b'


def question_2():
    # return ""
    return 'c'


def question_3():
    # return ""
    return 'b'



def question_4():
    # return ""
    return 'b'


def question_5():
    # return ""
    return 'a'

